[ { 'confs':'[请输入需要新增或者更新的会议名, 多个会议用空格分隔, 如：ecir kdd]', 'year':'[请输入从哪一年开始新增或者更新, 如: 2019]', 'filter':'默认留空就行', } ]

eg:
[{ "confs": "cvpr iclr nips eccv iccv aaai acl", "year": "2022", "filter": "" }]
